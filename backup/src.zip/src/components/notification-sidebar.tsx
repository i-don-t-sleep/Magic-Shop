"use client"

import { useState, useEffect } from "react"
import { X, ShoppingBag, Package, Bell, Star, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { LoadingComp } from "@/components/loading-comp"
import { fetchNotifications, markNotificationAsRead, markAllNotificationsAsRead } from "@/lib/notifications"
import type { Notification, NotificationCategory } from "@/types/notifications"

interface NotificationSidebarProps {
  open: boolean
  onClose: () => void
}

export function NotificationSidebar({ open, onClose }: NotificationSidebarProps) {
  const router = useRouter()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Fetch notifications when sidebar opens
  useEffect(() => {
    if (open) {
      loadNotifications()
    }
  }, [open])

  const loadNotifications = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const result = await fetchNotifications({ limit: 20 })
      setNotifications(result.notifications)
    } catch (err) {
      console.error("Failed to fetch notifications:", err)
      setError("Failed to load notifications. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleNotificationClick = async (notification: Notification) => {
    try {
      // Mark as read in the database
      if (!notification.is_read) {
        await markNotificationAsRead(notification.id.toString())
      }

      // Update local state
      setNotifications(notifications.map((n) => (n.id === notification.id ? { ...n, is_read: true } : n)))

      // Navigate to the relevant page
      if (notification.link_url) {
        router.push(notification.link_url)
      }

      // Close the sidebar
      onClose()
    } catch (err) {
      console.error("Failed to mark notification as read:", err)
    }
  }

  const handleMarkAllAsRead = async () => {
    try {
      // Mark all as read in the database
      await markAllNotificationsAsRead()

      // Update local state
      setNotifications(notifications.map((n) => ({ ...n, is_read: true })))
    } catch (err) {
      console.error("Failed to mark all notifications as read:", err)
    }
  }

  const getNotificationIcon = (category: NotificationCategory) => {
    switch (category) {
      case "order":
        return <ShoppingBag className="h-5 w-5 text-blue-500" />
      case "stock":
        return <Package className="h-5 w-5 text-green-500" />
      case "review":
        return <Star className="h-5 w-5 text-yellow-500" />
      case "system":
        return <AlertCircle className="h-5 w-5 text-red-500" />
      default:
        return <Bell className="h-5 w-5 text-zinc-400" />
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffSecs = Math.floor(diffMs / 1000)
    const diffMins = Math.floor(diffSecs / 60)
    const diffHours = Math.floor(diffMins / 60)
    const diffDays = Math.floor(diffHours / 24)

    if (diffSecs < 60) return "just now"
    if (diffMins < 60) return `${diffMins} minute${diffMins !== 1 ? "s" : ""} ago`
    if (diffHours < 24) return `${diffHours} hour${diffHours !== 1 ? "s" : ""} ago`
    if (diffDays < 7) return `${diffDays} day${diffDays !== 1 ? "s" : ""} ago`

    return date.toLocaleDateString()
  }

  const unreadCount = notifications.filter((n) => !n.is_read).length

  return (
    <div
      className={cn(
        "fixed inset-0 z-50 bg-black/50 backdrop-blur-sm transition-opacity",
        open ? "opacity-100" : "opacity-0 pointer-events-none",
      )}
      onClick={onClose}
    >
      <div
        className={cn(
          "absolute top-0 right-0 h-full w-full max-w-sm bg-magic-iron-1 shadow-xl transition-transform duration-300 ease-in-out",
          open ? "translate-x-0" : "translate-x-full",
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-[1px] bg-gradient-to-t from-magic-border-1 to-magic-border-2 h-full">
          <div className="p-[1px] bg-gradient-to-t from-magic-iron-1 from-20% to-magic-iron-2 to-80% h-full overflow-hidden">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-zinc-800">
                <div>
                  <h2 className="text-xl font-bold">Notifications</h2>
                  <p className="text-sm text-zinc-400">{unreadCount} unread</p>
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-zinc-700 text-white"
                    onClick={handleMarkAllAsRead}
                    disabled={unreadCount === 0 || isLoading}
                  >
                    Mark all as read
                  </Button>
                  <Button variant="ghost" size="icon" className="text-zinc-400" onClick={onClose}>
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Notification List */}
              <div className="flex-1 overflow-y-auto">
                {isLoading ? (
                  <div className="flex justify-center items-center h-40">
                    <LoadingComp />
                  </div>
                ) : error ? (
                  <div className="flex flex-col items-center justify-center h-40 p-4">
                    <AlertCircle className="h-12 w-12 text-red-500 mb-2" />
                    <p className="text-zinc-400 text-center">{error}</p>
                    <Button variant="outline" size="sm" className="mt-4 border-zinc-700" onClick={loadNotifications}>
                      Try Again
                    </Button>
                  </div>
                ) : notifications.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-40 p-4">
                    <Bell className="h-12 w-12 text-zinc-700 mb-2" />
                    <p className="text-zinc-500">No notifications</p>
                  </div>
                ) : (
                  <div className="divide-y divide-zinc-800">
                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={cn(
                          "p-4 hover:bg-zinc-800/50 cursor-pointer transition-colors",
                          !notification.is_read && "bg-zinc-800/20",
                        )}
                        onClick={() => handleNotificationClick(notification)}
                      >
                        <div className="flex gap-3">
                          <div className="flex-shrink-0 mt-1">{getNotificationIcon(notification.category)}</div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between">
                              <p className={cn("font-medium", !notification.is_read && "text-white")}>
                                {notification.title}
                              </p>
                              <span className="text-xs text-zinc-500 whitespace-nowrap ml-2">
                                {formatTimeAgo(notification.created_at)}
                              </span>
                            </div>
                            <p className="text-sm text-zinc-400 line-clamp-2">{notification.message}</p>
                          </div>
                          {!notification.is_read && (
                            <div className="flex-shrink-0 self-center">
                              <div className="w-2 h-2 rounded-full bg-red-600"></div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-zinc-800">
                <Button
                  variant="outline"
                  className="w-full border-zinc-700 text-white"
                  onClick={() => {
                    router.push("/SuperAdmins/notifications")
                    onClose()
                  }}
                >
                  View all notifications
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
