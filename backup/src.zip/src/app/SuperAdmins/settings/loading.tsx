import { LoadingComp } from "@/components/loading-comp"

export default function Loading() {
  return <LoadingComp />
}
