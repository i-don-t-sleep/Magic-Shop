"use client"

export default function paeg() {

  return (
    <div>
      <div className="flex flex-col h-screen">
        <div>wait wonderland??</div>
        <div className="flex-grow overflow-auto">
          dfjasdkfjaojihrotu2349htgi34uhg <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />{" "}
          <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />{" "}
          <br /> <br /> <br /> <br /> ds
        </div>
        <div>Footer</div>
      </div>
    </div>
  )
}
