"use client"

export default function vad() {

  return (
    <div>
      <div className="flex flex-col h-screen">
        <div>???</div>
        <div className="flex-grow overflow-auto">
          Wangshu!! <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />{" "}
          <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br /> <br />{" "}
          <br /> <br /> <br /> <br /> ds
        </div>
        <div>Footer</div>
      </div>
    </div>
  )
}
